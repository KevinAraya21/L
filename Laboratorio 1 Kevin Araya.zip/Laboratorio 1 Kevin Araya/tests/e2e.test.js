
const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');
const { InventoryPage } = require('../pages/InventoryPage');
const { CartPage } = require('../pages/CartPage');
const data = require('../data/users');

test.describe('SauceDemo E2E Tests', () => {

    test('Login successfully', async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();
        await login.login(data.validUser.username, data.validUser.password);
        await expect(page).toHaveURL(/inventory/);
    });

    test('Add item to cart and verify', async ({ page }) => {
        const login = new LoginPage(page);
        const inventory = new InventoryPage(page);
        const cart = new CartPage(page);

        await login.goto();
        await login.login(data.validUser.username, data.validUser.password);
        await inventory.addItemToCart();
        await inventory.goToCart();
        expect(await cart.isItemInCart()).toBeTruthy();
    });

    test('Logout from the app', async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();
        await login.login(data.validUser.username, data.validUser.password);
        await page.locator('#react-burger-menu-btn').click();
        await page.locator('#logout_sidebar_link').click();
        await expect(page).toHaveURL('https://www.saucedemo.com/');
    });
});
