
class CartPage {
    constructor(page) {
        this.page = page;
        this.cartItem = page.locator('.cart_item');
    }

    async isItemInCart() {
        return await this.cartItem.isVisible();
    }
}
module.exports = { CartPage };
