
Laboratorio 1 - Automatización de Pruebas con Playwright

Sitio Automatizado
https://www.saucedemo.com

Casos Cubiertos
1. Login exitoso
2. Agregar producto al carrito y verificarlo
3. Logout del sistema

